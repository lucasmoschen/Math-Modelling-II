package jycessing;

public enum DisplayType {
  WINDOWED,
  PRESENTATION;
}
